class ShoppingApiClient {
    constructor(baseUrl) {
        this.baseUrl = baseUrl;
    }

    async getItems() {
        const response = await fetch(this.baseUrl);
        return await response.json();
    }

    async addItem(item) {
        return await fetch(this.baseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(item)
        });
    }

    async updateItem(id, item) {
        return await fetch(`${this.baseUrl}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(item)
        });
    }

    async deleteItem(id) {
        return await fetch(`${this.baseUrl}/${id}`, {
            method: 'DELETE'
        });
    }
}

class ShoppingDomManager {
    constructor(listElementId, formElements) {
        this.listElement = document.getElementById(listElementId);
        this.nameInput = document.getElementById(formElements.nameInputId);
        this.qtyInput = document.getElementById(formElements.qtyInputId);
    }

    clearList() {
        this.listElement.replaceChildren();
    }

    renderItems(items, onEdit, onDelete) {
        this.clearList();
        items.forEach(item => {
            const li = this.createListItem(item, onEdit, onDelete);
            this.listElement.appendChild(li);
        });
    }

    createListItem(item, onEdit, onDelete) {
        const li = document.createElement('li');

        const span = document.createElement('span');
        span.className = 'item-info';

        const b = document.createElement('b');
        b.textContent = item.name;
        span.appendChild(b);

        const textNode = document.createTextNode(` (sztuk: ${item.quantity})`);
        span.appendChild(textNode);

        const divActions = document.createElement('div');
        divActions.className = 'actions';

        const editBtn = document.createElement('button');
        editBtn.className = 'edit-btn';
        editBtn.textContent = 'Edytuj';
        editBtn.onclick = () => onEdit(item);

        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'delete-btn';
        deleteBtn.textContent = 'Usuń';
        deleteBtn.onclick = () => onDelete(item.id);

        divActions.appendChild(editBtn);
        divActions.appendChild(deleteBtn);

        li.appendChild(span);
        li.appendChild(divActions);

        return li;
    }

    getFormData() {
        return {
            name: this.nameInput.value,
            quantity: this.qtyInput.value
        };
    }

    clearForm() {
        this.nameInput.value = '';
        this.qtyInput.value = '';
    }
}

class ShoppingApp {
    constructor(apiClient, domManager) {
        this.api = apiClient;
        this.dom = domManager;
    }

    async init() {
        await this.loadItems();
    }

    async loadItems() {
        try {
            const items = await this.api.getItems();
            this.dom.renderItems(
                items,
                (item) => this.handleEdit(item),
                (id) => this.handleDelete(id)
            );
        } catch (error) {
            console.error('Błąd połączenia z serwerem:', error);
            alert('Połączenie z serwerem się nie powiodło. Sprawdź, czy serwer jest uruchomiony.');
        }
    }

    async handleAdd() {
        const { name, quantity } = this.dom.getFormData();

        if (!name || !quantity) {
            alert('Proszę wypełnić wszystkie pola formularza.');
            return;
        }

        try {
            await this.api.addItem({ name, quantity: parseInt(quantity) });
            this.dom.clearForm();
            await this.loadItems();
        } catch (error) {
            console.error('Błąd połączenia z serwerem:', error);
            alert('Połączenie z serwerem się nie powiodło. Sprawdź, czy serwer jest uruchomiony.');
        }
    }

    async handleEdit(item) {
        const newName = prompt("Proszę podać nową nazwę produktu:", item.name);
        const newQty = prompt("Proszę podać nową ilość:", item.quantity);

        if (newName && newQty) {
            try {
                await this.api.updateItem(item.id, {
                    name: newName,
                    quantity: parseInt(newQty)
                });
                await this.loadItems();
            } catch (error) {
                console.error('Błąd połączenia z serwerem:', error);
                alert('Połączenie z serwerem się nie powiodło. Sprawdź, czy serwer jest uruchomiony.');
            }
        }
    }

    async handleDelete(id) {
        try {
            await this.api.deleteItem(id);
            await this.loadItems();
        } catch (error) {
            console.error('Błąd połączenia z serwerem:', error);
            alert('Połączenie z serwerem się nie powiodło. Sprawdź, czy serwer jest uruchomiony.');
        }
    }
}

// Inicjalizacja aplikacji
document.addEventListener('DOMContentLoaded', () => {
    const apiClient = new ShoppingApiClient('http://localhost:8080/api/shopping');
    const domManager = new ShoppingDomManager('shoppingList', {
        nameInputId: 'productName',
        qtyInputId: 'productQty'
    });

    const app = new ShoppingApp(apiClient, domManager);

    // Przypisanie funkcji dodawania do globalnego scope (dla atrybutu onclick w HTML)
    window.addItem = () => app.handleAdd();

    app.init();
});
