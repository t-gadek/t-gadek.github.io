package com.example.shopping.repository

import com.example.shopping.model.ShoppingItem
import org.springframework.stereotype.Repository
import java.io.File

@Repository
class CsvRepository {
    // Miejsce na podanie odpowiedniej ścieżki do pliku na dysku D:
    private val filePath = "D:\\\\shopping_list_db.csv"
    private val file = File(filePath)

    init {
        if (!file.exists()) file.createNewFile()
    }

    fun readAll(): List<ShoppingItem> {
        return file.readLines()
            .filter { it.isNotBlank() }
            .map { line ->
                val parts = line.split(",")
                ShoppingItem(id = parts[0], name = parts[1], quantity = parts[2].toInt())
            }
    }

    fun saveAll(items: List<ShoppingItem>) {
        val csvText = items.joinToString("\n") { "${it.id},${it.name},${it.quantity}" }
        file.writeText(csvText)
    }
}
