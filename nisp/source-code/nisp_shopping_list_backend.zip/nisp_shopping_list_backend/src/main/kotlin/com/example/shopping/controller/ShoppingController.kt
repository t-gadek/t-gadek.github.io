package com.example.shopping.controller

import com.example.shopping.model.ShoppingItem
import com.example.shopping.service.ShoppingService
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("/api/shopping")
@CrossOrigin(origins = ["*"])
class ShoppingController(private val service: ShoppingService) {

    private val log: Logger = LoggerFactory.getLogger(ShoppingController::class.java)

    @GetMapping
    fun getItems(): List<ShoppingItem> {

        log.info("Server pobiera liste zakupow...")
        return service.getAllItems()
    }

    @PostMapping
    fun createItem(@RequestBody item: ShoppingItem): ShoppingItem {
        log.info("Server dodaje elment '${item.name}' do listy...")
        return service.addItem(item)
    }

    @PutMapping("/{id}")
    fun updateItem(@PathVariable id: String, @RequestBody item: ShoppingItem): ShoppingItem? {
        log.info("Server aktualizuje elment id = ${id} na liscie...")
        return service.updateItem(id, item)
    }

    @DeleteMapping("/{id}")
    fun deleteItem(@PathVariable id: String) {
        log.info("Server usuwa elment id = ${id} z listy...")
        service.deleteItem(id)
    }
}
