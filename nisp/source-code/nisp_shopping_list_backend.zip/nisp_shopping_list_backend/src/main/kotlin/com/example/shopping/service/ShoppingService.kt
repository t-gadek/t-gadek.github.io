package com.example.shopping.service

import com.example.shopping.model.ShoppingItem
import com.example.shopping.repository.CsvRepository
import org.springframework.stereotype.Service

@Service
class ShoppingService(private val repository: CsvRepository) {

    fun getAllItems(): List<ShoppingItem> = repository.readAll()

    fun addItem(item: ShoppingItem): ShoppingItem {
        val items = repository.readAll().toMutableList()
        items.add(item)
        repository.saveAll(items)
        return item
    }

    fun updateItem(id: String, updatedItem: ShoppingItem): ShoppingItem? {
        val items = repository.readAll().toMutableList()
        val index = items.indexOfFirst { it.id == id }
        
        if (index != -1) {
            items[index] = updatedItem.copy(id = id)
            repository.saveAll(items)
            return items[index]
        }
        return null
    }

    fun deleteItem(id: String) {
        val items = repository.readAll().filter { it.id != id }
        repository.saveAll(items)
    }
}
